pub fn default_greeting() -> String {
    let message = String::from("greetings in english");
    message
}