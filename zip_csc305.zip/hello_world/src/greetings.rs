pub mod french;
pub mod spanish;
pub mod english;

///greeting function simply returns a String
pub fn default_greeting() -> String {
    let message = String::from("Hi!");
    message
    }